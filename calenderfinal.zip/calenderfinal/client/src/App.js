import Calendar from "./components/Calendar";
import Header from './Navbar';
import './App.css';

function App() {
  return (
    <div>
    <div>
        {/* <Header /> */}
    </div>
    <div className="App">
      <Calendar />
    </div>
    </div>
  );
}

export default App;

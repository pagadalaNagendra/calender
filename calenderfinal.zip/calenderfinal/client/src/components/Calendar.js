import React, { useState, useEffect, useRef } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import axios from "axios";
import Swal from "sweetalert2";
import "./ScheduleCalendar.css";

function ScheduleCalendar() {
  const [events, setEvents] = useState([]);
  const calendarRef = useRef(null);
  

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await axios.get("http://localhost:2500/calendarschema");
        const calendarEvents = response.data.map((event) => {
          return {
            title: event.title,
            start: new Date(event.start),
            emails: event.emails,
            id: event._id,
          };
        });
        setEvents(calendarEvents);

      } catch (error) {
        console.error(error);
      }
    }
    fetchData();
  }, []);


  setInterval(() => checkUpcomingEvents(), 1000);

  const triggeredAlerts = new Set(); 
  
  async function checkUpcomingEvents() {
    try {
      const eventTimesResponse = await axios.get("http://localhost:2500/eventtimes");
      const eventTimes = eventTimesResponse.data;
      const now = new Date();
      const current_hours = now.getHours();
      const current_minutes = now.getMinutes();
      const current_seconds = now.getSeconds();
      const current_totalSeconds = current_hours * 3600 + current_minutes * 60 + current_seconds;
      const formattedDate = `${getDayName(currentDate.getUTCDay())} ${getMonthName(currentDate.getUTCMonth())} ${padWithZeros(currentDate.getUTCDate(), 2)} ${currentDate.getUTCFullYear()} ${padWithZeros(currentDate.getUTCHours(), 2)}:${padWithZeros(currentDate.getUTCMinutes(), 2)}:${padWithZeros(currentDate.getUTCSeconds(), 2)} GMT+0530 (India Standard Time)`;
      const today = formattedDate.slice(0,16)
  
      eventTimes.forEach((event) => {
        const [hours, minutes] = event.alertTime.split(":").map(Number);
        const totalSeconds = hours * 3600 + minutes * 60;
        const timeDifference = totalSeconds- current_totalSeconds;
        const eventDate = event.start.slice(0,16)
        if(timeDifference===0 && eventDate===today){
          checkAlertTiming(event,timeDifference,"event started")
        }
        else if(timeDifference===15*60 && eventDate===today){
          checkAlertTiming(event,timeDifference,"event will start in 15min")
        }
        else if(timeDifference===30*60 && eventDate===today){
          checkAlertTiming(event,timeDifference,"event will start in 30min")
        }
        else if(timeDifference===60*60 && eventDate===today){
          checkAlertTiming(event,timeDifference,"event will start in 60min")
        }
      });
    } catch (error) {
      console.error(error);
    }
  }

  async function checkAlertTiming(event, timeDifference, alertType) {
    
    const eventAlertType = {
      event,
      alertType
    }
    if (!triggeredAlerts.has(eventAlertType)) {
      displayAlert(event, alertType);
      triggeredAlerts.add(eventAlertType);
      const mails= {
        emails:event.emails
      }
      const sendMail = await axios.post("http://localhost:2500/sendMail",mails);
      console.log(sendMail)
    }
  }

  function displayAlert(event, alertType) {
    Swal.fire({
      title: `Event Alert - ${event.title} ${alertType} at ${event.alertTime}`,
      text: `'${event.title}' ${alertType} `,

      icon: "info",
      confirmButtonText: "OK",
    });
  }

  function isValidEmail(emails) {
    const emailsArray = emails.split(",")
    let result=false
    for (let i of emailsArray){
      result = i.includes("@")
      if(!result){
        break;
      }
    }
    return result
  }


  const currentDate = new Date();

  function getDayName(day) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return days[day];
  }

  function getMonthName(month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month];
  }

  function padWithZeros(num, length) {
    return num.toString().padStart(length, '0');
  }

  
  async function handleDateSelect(selectInfo) {
    console.log(selectInfo.start);
    const eventDate = String(selectInfo.start).slice(0, 16);
  
    Swal.fire({
      title: "Enter event details",
      html:
        '<input id="title" class="swal2-input" placeholder="Event title">' +
        '<input id="emails" class="swal2-input" placeholder="Email">' +
        '<input id="eventTime" class="swal2-input" type="time" placeholder="Event time">',
      showCancelButton: true,
      confirmButtonText: "Create",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        const title = document.getElementById("title").value;
        const emails = document.getElementById("emails").value;
        const eventTime = document.getElementById("eventTime").value;
  
        let calendarApi = selectInfo.view.calendar;
        calendarApi.unselect();
        if (title && isValidEmail(emails)) {
          const end = new Date(selectInfo.endStr);
  
          end.setHours(eventTime.split(":")[0]);
          end.setMinutes(eventTime.split(":")[1]);
          const newEvent = {
            title,
            emails,
            start: eventDate,
            end,
            eventTime,
          };

          axios.post("http://localhost:2500/sendMail",newEvent)
          .then(response=>{
            console.log(response)
          })
          // console.log(sendMail)
          axios
            .post("http://localhost:2500/calendarschema", newEvent)
            .then((response) => {
              const updatedEvents = [...events, { ...newEvent, id: response.data._id }];
              setEvents(updatedEvents);
              window.location.reload()
              
            })
            .catch((error) => {
              console.error("Error adding event:", error);
            });
            
        } else {
          Swal.fire("Error", "Please enter a valid email and title", "error");
        }
      }
    });
  }
  
  
  function handleEventRemove(clickInfo) {
    Swal.fire({
      title: `Are you sure you want to delete the event '${clickInfo.event.title}'?`,
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, keep it",
    }).then((result) => {
      if (result.isConfirmed) {
        axios.delete(`http://localhost:2500/calendarschema/${clickInfo.event.id}`).then(() => {
          const filteredEvents = events.filter((event) => event.id !== clickInfo.event.id);
          setEvents(filteredEvents);
        });
      }
    });
  }

  function handleEventUpdate(updateInfo, calendarApi) {
    const { event } = updateInfo;
    const updatedEvent = {
      ...event,
      start: updateInfo.start,
      end: updateInfo.end,
    };
    axios.put(`http://localhost:2500/calendarschema/${event.id}`, updatedEvent).then(() => {
      calendarApi.getApi().updateEvent(updatedEvent);
    });
  }

  return (
    <div>
      <FullCalendar
        ref={calendarRef}
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        selectable={true}
        select={handleDateSelect}
        headerToolbar={{
          start: "today prev,next",
          center: "title",
          end: "dayGridMonth,timeGridWeek,timeGridDay",
        }}
        editable={true}
        eventDurationEditable={true}
        eventResize={(updateInfo) => handleEventUpdate(updateInfo, calendarRef)}
        eventDrop={(updateInfo) => handleEventUpdate(updateInfo, calendarRef)}
        eventClick={handleEventRemove}
        events={events}
      />
    </div>
  );
}

export default ScheduleCalendar;
